---
title: "Reference: Mastra.getLogsByRunId() | Core | Mastra Docs"
description: "Documentation for the `Mastra.getLogsByRunId()` method in Mastra, which retrieves logs for a specific run ID and transport ID."
---

# Mastra.getLogsByRunId()
[EN] Source: https://mastra.ai/en/reference/core/getLogsByRunId

The `.getLogsByRunId()` method is used to retrieve logs for a specific run ID and transport ID. This method requires a configured logger that supports the `getLogsByRunId` operation.

## Usage example

```typescript copy
mastra.getLogsByRunId({ runId: "123", transportId: "456" });
```

## Parameters

<PropertiesTable
  content={[
    {
      name: "runId",
      type: "string",
      description: "The run ID to retrieve logs for.",
    },
    {
      name: "transportId",
      type: "string",
      description: "The transport ID to retrieve logs from.",
    },
    {
      name: "fromDate",
      type: "Date",
      description: "Optional start date for filtering logs. e.g., new Date('2024-01-01').",
      optional: true,
    },
    {
      name: "toDate",
      type: "Date",
      description: "Optional end date for filtering logs. e.g., new Date('2024-01-31').",
      optional: true,
    },
    {
      name: "logLevel",
      type: "LogLevel",
      description: "Optional log level to filter by.",
      optional: true,
    },
    {
      name: "filters",
      type: "Record<string, any>",
      description: "Optional additional filters to apply to the log query.",
      optional: true,
    },
    {
      name: "page",
      type: "number",
      description: "Optional page number for pagination.",
      optional: true,
    },
    {
      name: "perPage",
      type: "number",
      description: "Optional number of logs per page for pagination.",
      optional: true,
    },
  ]}
/>

## Returns

<PropertiesTable
  content={[
    {
      name: "logs",
      type: "Promise<any>",
      description: "A promise that resolves to the logs for the specified run ID and transport ID.",
    },
  ]}
/>

## Related

- [Logging overview](../../docs/observability/logging.mdx)
- [Logger reference](../../reference/observability/logger.mdx)


