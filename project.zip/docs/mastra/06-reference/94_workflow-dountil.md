---
title: "Reference: Workflow.dountil() | Workflows | Mastra Docs"
description: Documentation for the `Workflow.dountil()` method in workflows, which creates a loop that executes a step until a condition is met.
---

# Workflow.dountil()
[EN] Source: https://mastra.ai/en/reference/workflows/workflow-methods/dountil

The `.dountil()` method executes a step until a condition is met. It always runs the step at least once before evaluating the condition. The first time the condition is evaluated, `iterationCount` is `1`.

## Usage example

```typescript copy
workflow.dountil(step1, async ({ inputData }) => true);
```

## Parameters

<PropertiesTable
  content={[
    {
      name: "step",
      type: "Step",
      description: "The step instance to execute in the loop",
      isOptional: false,
    },
    {
      name: "condition",
      type: "(params : ExecuteParams & { iterationCount: number }) => Promise<boolean>",
      description:
        "A function that returns a boolean indicating whether to continue the loop. The function receives the execution parameters and the iteration count.",
      isOptional: false,
    },
  ]}
/>

## Returns

<PropertiesTable
  content={[
    {
      name: "workflow",
      type: "Workflow",
      description: "The workflow instance for method chaining",
    },
  ]}
/>

## Related

- [Control Flow](../../../docs/workflows/control-flow.mdx)

- [ExecuteParams](../step.mdx#ExecuteParams)


